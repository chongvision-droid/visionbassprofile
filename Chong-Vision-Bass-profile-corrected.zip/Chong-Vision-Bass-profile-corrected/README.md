# Chong Vision Bass Profile

Corrected GitHub Pages version of the Chong Vision bassist portfolio.

## Folder structure

```text
Chong-Vision-Bass-profile/
├── index.html
├── README.md
├── images/
│   ├── hero.jpg
│   └── performance.jpg
└── videos/
    ├── work-01.mp4
    ├── work-02.mp4
    └── work-03.mp4
```

## Important: media filenames

GitHub Pages is case-sensitive. The website expects these exact filenames:

- `images/hero.jpg`
- `images/performance.jpg`
- `videos/work-01.mp4`
- `videos/work-02.mp4`
- `videos/work-03.mp4`

Do not rename them to `Hero.JPG`, `Performance.JPG`, `work 01.mp4`, etc.

If you only have one or two videos, you can leave the unused video files out; their cards will show the placeholder instead of breaking the page.

## GitHub Pages

1. Upload/replace the files in the repository root.
2. Go to **Settings → Pages**.
3. Set **Deploy from a branch**.
4. Select the `main` branch and `/ (root)`.
5. Save and wait for the deployment.
6. Open the generated GitHub Pages URL.

The HTML uses relative paths (`./images/...` and `./videos/...`) so it works correctly from a GitHub Pages project URL such as:

`https://chongvision-droid.github.io/Chong-Vision-Bass-profile/`
